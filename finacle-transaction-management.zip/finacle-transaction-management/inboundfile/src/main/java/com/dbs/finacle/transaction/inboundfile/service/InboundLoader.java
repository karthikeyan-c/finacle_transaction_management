package com.dbs.finacle.transaction.inboundfile.service;

import com.dbs.finacle.transaction.core.dao.*;
import com.dbs.finacle.transaction.core.repository.TransactionRecordRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class InboundLoader {
    @Autowired
    UploadService uploadService;

    public boolean loadInboundFile(String file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line = "";
            Long counter = 0L;
            while ((line = br.readLine()) != null) {
                //01BKSP2941                DQSP002894621700070N01351000015000000390CDP    D3        Test Long Description with 35 char                                                                     1I s 00000200000                                                EOF
                // marshal
                uploadService.insertRecord(line, file, ++counter);
            }
        } catch (IOException | ParseException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public Boolean checkCompletion() {
        return uploadService.checkCompletion();
    }
}
