package com.dbs.finacle.transaction.inboundfile.runner;

import com.dbs.finacle.transaction.inboundfile.service.InboundLoader;
import com.dbs.finacle.transaction.inboundfile.service.OutboundLoader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class FileProcessorRunner implements CommandLineRunner {
    @Autowired
    InboundLoader inboundLoader;
    @Autowired
    OutboundLoader outboundLoader;
    @Autowired
    private ConfigurableApplicationContext context;
    @Value("${ewss.config.iteration:10}")
    private Integer iteration;
    @Value("${ewss.config.sleep:5000}")
    private Long sleepWindow;

    public void run(String... args) throws Exception {
        log.info("start filesss uploading....");
        // Load file and trigger EWSS outbound
        inboundLoader.loadInboundFile("./STAGING/customer.txt");

        // Wait for complete responses.
        for (int i = 0; i <= iteration; i++) {
            if (inboundLoader.checkCompletion()) break;
            else {
                Thread.sleep(sleepWindow);
            }
        }
        // Write file
        outboundLoader.extractOutput();
        // Close
//        context.close();
    }
}
