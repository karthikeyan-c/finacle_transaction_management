package com.dbs.finacle.transaction.inboundfile.service;

import com.dbs.finacle.transaction.core.dao.*;
import com.dbs.finacle.transaction.core.repository.TransactionRecordRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class UploadService {
    @Autowired
    TransactionRecordRepository transactionRecordRepository;

    @Async
    public Long insertRecord(String line, String file, Long counter) throws ParseException {
        line = " ".concat(line);
        String recType          =   line.substring(1, 2);
        String origSystemId     =   line.substring(3, 6);
        String origSystemKey    =   line.substring(7, 26);
        String targetSystemId   =   line.substring(27, 30);
        String acctNumber       =   line.substring(31, 44);
        log.info("acctNumber is " + acctNumber);
        String transactionCode  =   line.substring(45, 50);
        String creditDebitInd   =   line.substring(51, 52);
        log.info("creditDebitInd is " + creditDebitInd);
        creditDebitInd          =   creditDebitInd.equals("1") ? "D" : "C";
        String tranAmt          =   line.substring(52, 62);
        BigDecimal BTranAmt     =   BigDecimal.valueOf(Long.parseLong(tranAmt)).divide(BigDecimal.valueOf(100), RoundingMode.CEILING);
        String branchOfTran     =   line.substring(63, 66);
        String tranRef          =   line.substring(67, 73);
        String brandInd         =   line.substring(74, 74);
        String insuffFundInd    =   line.substring(75, 75);
        String valueDate        =   line.substring(76, 83);
        String addnlRef1        =   line.substring(84, 117);
        String addnlRef2        =   line.substring(118, 151);
        String addnlRef3        =   line.substring(152, 185);
        String holdInd          =   line.substring(186, 186);
        String noSuspenseInd    =   line.substring(187, 187);
        String acctNumberInd    =   line.substring(188, 188);
        String addnlRef135      =   line.substring(189, 189);
        String addnlRef235      =   line.substring(190, 190);
        String addnlRef335      =   line.substring(191, 191);
        String inactiveInd      =   line.substring(192, 192);
        String deceasedInd      =   line.substring(193, 193);
        String bankruptInd      =   line.substring(194, 194);
        String unsoundMindInd   =   line.substring(195, 195);
        String loanInd          =   line.substring(196, 196);
        String frozenInd        =   line.substring(197, 197);
        String noDebitInd       =   line.substring(198, 198);
        String recallPassbookInd=   line.substring(199, 199);
        String debitReferralInd =   line.substring(200, 200);
        String sigIrregularInd  =   line.substring(201, 201);
        String closureLetterInd =   line.substring(202, 202);
        String filler           =   line.substring(203, 250);

        // Store raw records.
        TransactionHeaderKey transactionHeaderKey = new TransactionHeaderKey();
        TransactionHeader transactionHeader = new TransactionHeader();
        transactionHeader.setTransactionHeaderKey(transactionHeaderKey);
        List<TransactionDetail> transactionDetailList = new ArrayList<>();
        transactionHeader.setTransactionDetails(transactionDetailList);

        transactionHeaderKey.setHeaderId(counter);
        transactionHeaderKey.setHeaderDate(new Date());
        transactionHeaderKey.setFileName(file);
        transactionHeader.setRecord(line);

        //Status
        Status status = new Status();
        status.setRecordStatus('R');
        status.setTranStatus('R');
        transactionHeader.setStatus(status);

        //Enrich
        TransactionDetail transactionDetail = new TransactionDetail(line);
        TransactionDetailKey transactionDetailKey = new TransactionDetailKey();
        transactionDetailKey.setTransactionHeaderKey(transactionHeaderKey);
        transactionDetailKey.setPartTranSrlNum(1L);
        transactionDetail.setTransactionDetailKey(transactionDetailKey);

        transactionDetail.setForacid(acctNumber);
        transactionDetail.setAmount(BTranAmt);
        transactionDetail.setCurrency("INR");
        transactionDetail.setDebitOrCredit(creditDebitInd);
        transactionDetail.setParticulars("particular");
        transactionDetail.setParticulars2("particular2");
        transactionDetail.setRemarks("remarks");
        transactionDetail.setValueDate(new Date());
        transactionDetailList.add(transactionDetail);
        log.info("transactionRecord is " + transactionDetail);

        TransactionDetail transactionDetail2 = new TransactionDetail(line);
        TransactionDetailKey transactionDetailKey2 = new TransactionDetailKey();
        transactionDetailKey2.setTransactionHeaderKey(transactionHeaderKey);
        transactionDetailKey2.setPartTranSrlNum(2L);
        transactionDetail2.setTransactionDetailKey(transactionDetailKey2);

        transactionDetail2.setForacid("0529301000004761");
        transactionDetail2.setAmount(BTranAmt);
        transactionDetail2.setCurrency("INR");
        transactionDetail2.setDebitOrCredit(transactionDetail.getDebitOrCredit().equals("D") ? "C" : "D");
        transactionDetail2.setParticulars("particular");
        transactionDetail2.setParticulars2("particular2");
        transactionDetail2.setRemarks("remarks");
        transactionDetail2.setValueDate(new Date());
        transactionDetailList.add(transactionDetail2);
        log.info("transactionRecord2 is " + transactionDetail2);

        // Ignore Header and trailer
        // Read actual records & call EWSS
//                customerFile.setEwssRef(ewssService.callEWSSAsync(customerRecord));
        log.info("transactionHeader is " + transactionHeader);
        transactionRecordRepository.saveAndFlush(transactionHeader);
        return counter;
    }

    public Boolean checkCompletion() {
        long statusCount = transactionRecordRepository.count();
        long recCount = transactionRecordRepository.count();
        log.info(" Completed count : " + statusCount + "/" + recCount);
        return statusCount >= recCount;
    }
}
