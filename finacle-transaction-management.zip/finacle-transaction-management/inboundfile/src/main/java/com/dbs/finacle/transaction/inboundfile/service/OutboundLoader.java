package com.dbs.finacle.transaction.inboundfile.service;

import com.dbs.finacle.transaction.core.repository.TransactionRecordRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

@Service
@Slf4j
public class OutboundLoader {
    @Autowired
    TransactionRecordRepository customerRecordRepository;

    public Boolean extractOutput() {
        try(BufferedWriter outBuff = new BufferedWriter(new FileWriter("./STAGING/output.txt"))) {
            customerRecordRepository
                    .findAll()
                    .forEach( customerFile -> {
                        String status = "NOT-KNOWN";

                        String outRec = customerFile.getRecord() + "|" + status;
                        try {
                            log.info("outRec is " + outRec);
                            outBuff.append(outRec);
                            outBuff.newLine();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
}
