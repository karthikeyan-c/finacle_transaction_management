package com.dbs.finacle.transaction.daemon.controller;

import com.dbs.finacle.transaction.core.dao.TransactionHeader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@Slf4j
@RequestMapping("/api/v1")
public class FinacleStubController {
    @PostMapping("/stub")
    public ResponseEntity<String> postStub(@RequestBody TransactionHeader transactionHeader) {
//        log.info("transactionHeader is " + transactionHeader);
        log.info("stub service execution for : " + transactionHeader.getTransactionHeaderKey().getHeaderId());
        String uniqRef = UUID.randomUUID().toString();
        return new ResponseEntity<>(uniqRef, HttpStatus.OK);
    }
}
