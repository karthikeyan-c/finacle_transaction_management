package com.dbs.finacle.transaction.daemon.service;

import com.dbs.finacle.transaction.core.dao.TransactionHeader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.concurrent.CompletableFuture;

@Service
@Slf4j
public class CallFinacleService {
    @Value("${finacle.config.url}")
    private String finacleUrl;

    @Autowired
    RestTemplate restTemplate;

    @Async
    public CompletableFuture<String> callFinacleAsync(TransactionHeader transactionHeader) {
        String result = restTemplate.postForObject(UriComponentsBuilder
                        .fromUriString(finacleUrl)
                        .build()
                        .toUri(), transactionHeader, String.class);
        return CompletableFuture.completedFuture(result);
    }
}
