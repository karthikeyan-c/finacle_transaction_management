package com.dbs.finacle.transaction.daemon.service;

import com.dbs.finacle.transaction.core.dao.TransactionHeader;
import com.dbs.finacle.transaction.core.repository.TransactionRecordRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class DaemonService {
    @Autowired
    CallFinacleService callFinacleService;
    @Autowired
    TransactionRecordRepository transactionRecordRepository;

    @Scheduled(fixedDelay = 5000)
    public void pollAndProcessFinacleTransaction() {
        log.info("running ");
        int page=0;
        int size=10;
        boolean pageExists = true;
        Pageable paging = PageRequest.of(page, size);

        while (pageExists) {
            Page<TransactionHeader> readyRecords = transactionRecordRepository.findByStatusRecordStatus('R', paging);
//            log.info("readyRecords is" + readyRecords);

            readyRecords.forEach(transactionHeader -> {
                log.info("record: " + transactionHeader.getTransactionHeaderKey().getHeaderId());
                CompletableFuture<String> finacleResponse = callFinacleService.callFinacleAsync(transactionHeader);
                try {
                    String response = finacleResponse.get();
                    transactionHeader.getStatus().setTranId(response);
                    transactionHeader.getStatus().setTranDate(new Date());
                    transactionHeader.getStatus().setRecordStatus('S');
                    transactionRecordRepository.saveAndFlush(transactionHeader);
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            });
            pageExists = !readyRecords.isLast();
            paging = PageRequest.of(++page, size);
        }
    }
}
