package com.dbs.finacle.transaction.outboundfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutboundfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
