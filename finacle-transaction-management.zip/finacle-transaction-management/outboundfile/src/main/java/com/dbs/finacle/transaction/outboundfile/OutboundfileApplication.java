package com.dbs.finacle.transaction.outboundfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutboundfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(OutboundfileApplication.class, args);
	}

}
