package com.dbs.finacle.transaction.core.dao;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;

@Entity
@Getter
@Setter
@Slf4j
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "TRAN_DETAIL_TABLE", schema = "DBSBAT")
public class TransactionDetail {
//    {"subtype":"CI","type":"T","exceptionMode":"exception","deliveryChannelId":"IPE","entries":[{"foracid":"0103301000004761","currency":"INR","amount":"2.00","debitOrCredit":"D","remarks":"AEITTSECOND
//        TEST","valueDate":"2023-01-12T00:00:00","lienId":"","referenceNum":"0800OT0117605","particulars":"AEITTSECOND","particulars2":"SAMPLE
//        TPC-2","particularCode":"IPE01"},{"foracid":"0103301000004761","currency":"INR","amount":"2.00","debitOrCredit":"C","remarks":"TEST2","valueDate":"2023-01-12T00:00:00","lienId":"","referenceNum":"0800OT0117605","particulars":"REMITTANCE
//        0821IT0009935","particulars2":"SAMPLE
//        TPC-2","particularCode":"IPE01"}]}
    @EmbeddedId
    private TransactionDetailKey transactionDetailKey;
    private String foracid;
    private String currency;
    private BigDecimal amount;
    private String debitOrCredit;
    private String remarks;
    private Date valueDate;
    private String lienId;
    private String referenceNum;
    private String particulars;
    private String particulars2;
    private String particularCode;

//    @ManyToOne
//    @JoinColumns({
//            @JoinColumn(name = "TRANSACTION_DETAIL_KEY.TRANSACTION_HEADER_KEY_HEADERID", referencedColumnName = "HEADERID"),
//            @JoinColumn(name = "TRANSACTION_DETAIL_KEY.TRANSACTION_HEADER_KEY_HEADERDATE", referencedColumnName = "HEADERDATE")
//    })
//    private TransactionHeader transactionHeader;

    public TransactionDetail(String line) throws ParseException {
        log.info("line is " + line);
        String[] value = line.split("\\|");
        log.info("value length" + value.length);
//
//        Entry entry = new Entry();
//        entry.setForacid(value[0]);
//        entry.setAmount(BigDecimal.valueOf(Double.parseDouble(value[1])));
//        entry.setCurrency(value[2]);
//        entry.setDebitOrCredit(value[3]);
//        entry.setRemarks(value[4]);
//        entry.setValueDate(new SimpleDateFormat("ddMMyyyy").parse(value[5]));
//        entry.setLienId(value[6]);
//        entry.setReferenceNum(value[7]);
//        entry.setParticulars(value[8]);
//        entry.setParticulars2(value[9]);
//        entry.setParticularCode(value[10]);
    }
}
