package com.dbs.finacle.transaction.core.dao;

import lombok.Data;
import lombok.ToString;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import java.io.Serializable;

@Data
@ToString
@Embeddable
public class TransactionDetailKey implements Serializable {
    //Foreign Key
    @Embedded
    private TransactionHeaderKey transactionHeaderKey;
    private Long partTranSrlNum;
}
