package com.dbs.finacle.transaction.core.dao;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Date;

@Data
@Getter
@Setter
@ToString
@Embeddable
public class TransactionHeaderKey implements Serializable {
//    @Id
//    @GeneratedValue
    private Long headerId;
    private Date headerDate;
    private String fileName;
}
