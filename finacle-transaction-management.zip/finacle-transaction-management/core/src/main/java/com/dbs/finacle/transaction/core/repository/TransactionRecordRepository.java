package com.dbs.finacle.transaction.core.repository;

import com.dbs.finacle.transaction.core.dao.TransactionHeader;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.LockModeType;


@Repository
public interface TransactionRecordRepository extends JpaRepository<TransactionHeader, Long> {
//    List<TransactionHeader> findByStatusRecordStatus(Character recordStatus);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRES_NEW)
    Page<TransactionHeader> findByStatusRecordStatus(Character recordStatus, Pageable pageable);
}
