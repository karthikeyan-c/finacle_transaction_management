package com.dbs.finacle.transaction.core.dao;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
//@ToString
@Table(name = "TRAN_HEADER_TABLE",schema = "DBSBAT")
public class TransactionHeader {
    @EmbeddedId
    private TransactionHeaderKey transactionHeaderKey;

    private String record;
    private String tranType="T";
    private String tranSubType="BI";
    private String exceptionMode="exception";
    private String deliveryChannelId="COR";

    @OneToMany(fetch = FetchType.EAGER,
            mappedBy = "transactionDetailKey.transactionHeaderKey",
            orphanRemoval = true,
            cascade = CascadeType.ALL)
    private List<TransactionDetail> transactionDetails = new ArrayList<>();

    @Embedded
    private Status status = new Status();

    @CreationTimestamp
    private Timestamp entry_time;
    private Timestamp modified_time;
}
