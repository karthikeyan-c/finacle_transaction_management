package com.dbs.finacle.transaction.core.dao;

import lombok.Data;
import org.springframework.lang.Nullable;

import javax.persistence.Embeddable;
import java.util.Date;

@Data
@Embeddable
public class Status {
    private Character recordStatus;
    private String recordError;
    private Character tranStatus;
    private String tranError;
    private String tranId;
    private Date tranDate;
}
